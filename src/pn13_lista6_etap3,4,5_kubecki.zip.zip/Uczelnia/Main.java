package Uczelnia;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
//      Odczyt danych
        ArrayList<Osoba> osoby  = new ArrayList<>();
        ArrayList<Kurs> kursy   = new ArrayList<>();
        Metody.deserializuj(osoby,kursy, "serializacja");

        //-------------------------------------------------------------------------------------------------------------
        //Operacje użytkownika
        Metody.sesjaUrzytkownika(kursy,osoby);

//        Wypisywanie danych
    //        System.out.println("--------------Studenci----------------");
    //        Metody.wypiszStudentow(osoby);
    //        System.out.println("--------------Pracownicy--------------");
    //        Metody.wypiszPracownikow(osoby);
    //        System.out.println("--------------Kursy-------------------");
    //        Metody.wypiszKursy(kursy);


//      Zapis danych
//      TODO Dopisywanie nowych danych
        Metody.serializuj(osoby, kursy,"serializacja");
    }
}