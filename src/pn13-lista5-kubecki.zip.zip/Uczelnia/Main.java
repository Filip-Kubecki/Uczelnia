package Uczelnia;
//Klasa na metody
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        ArrayList<Osoba> osoby = new ArrayList<>();
        ArrayList<Kurs> kursy = new ArrayList<>();

        Kurs fizyka = new Kurs("Fizyka1","Jan Misiewicz",4);
        kursy.add(fizyka);

        Student s1 = new Student("Filip","Kubecki","02224428542",20,"Male",272655,1, (ArrayList<Kurs>) kursy,false,true,false,true,false);
        osoby.add(s1);

        PracownikBadawczoDydaktyczny p1 = new PracownikBadawczoDydaktyczny("Krzysztof","Kowalski","23465826",54,"Male",5,7845,6, PracownikBadawczoDydaktyczny.stanowiskoPracy.ProfesorZwyczajny);
        PracownikBadawczoDydaktyczny p2 = new PracownikBadawczoDydaktyczny("Janusz","Bimbala","23465826",54,"Male",5,7845,6, PracownikBadawczoDydaktyczny.stanowiskoPracy.Adiunktt);
        osoby.add(p1);
        osoby.add(p2);

        Kurs k1 = new Kurs("Fizyka","Jacak",5);
        kursy.add(k1);
        Kurs k2 = new Kurs("Analiza1","Augustyniak",6);
        kursy.add(k2);

        Metody.wpiszDane(osoby,kursy);
    }
}