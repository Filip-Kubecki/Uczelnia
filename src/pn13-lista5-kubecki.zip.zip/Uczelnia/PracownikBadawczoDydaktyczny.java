package Uczelnia;

public class PracownikBadawczoDydaktyczny extends PracownikUczelni{
    public enum stanowiskoPracy {
        Asystent,
        Adiunktt,
        ProfesorNadzwyczajny,
        ProfesorZwyczajny,
        Wykładowca;
    }
    private int liczbaPublikacji;
    private stanowiskoPracy stanowisko;

    public PracownikBadawczoDydaktyczny(String imie, String nazwisko, String PESEL, int wiek, String plec, int stazPracy, int pensja, int liczbaPublikacji, stanowiskoPracy stanowisko) {
        super(imie, nazwisko, PESEL, wiek, plec, stazPracy, pensja);
        this.liczbaPublikacji = liczbaPublikacji;
        this.stanowisko = stanowisko;
    }

    public int getLiczbaPublikacji() {
        return liczbaPublikacji;
    }

    public void setLiczbaPublikacji(int liczbaPublikacji) {
        this.liczbaPublikacji = liczbaPublikacji;
    }
}
