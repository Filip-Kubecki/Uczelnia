package Uczelnia;

import java.util.List;
import java.util.Scanner;

public class Metody {
    public static void wypiszPracownikow(List<Osoba> osoby){
        for (Osoba osoba : osoby) {
            if (osoba instanceof PracownikUczelni){
                System.out.println(osoba.imie+" "+osoba.nazwisko+" "+osoba.PESEL);
            }
        }
    }
    public static void wypiszStudentow(List<Osoba> osoby){
        for (Osoba osoba : osoby) {
            if (osoba instanceof Student){
                System.out.println(osoba.imie+" "+osoba.nazwisko+" "+osoba.PESEL+" ");
            }
        }
    }
    public static void wypiszKursy(List<Kurs> kursy){
        for (Kurs kurs : kursy) {
            if (kurs instanceof Kurs){
                System.out.println(kurs.getNazwaKursu()+" "+kurs.getProwadzacy()+" "+kurs.getPunktyECTS());
            }
        }
    }
    public static void szukajStudenta(List<Osoba> osoby){
        for (Osoba osoba : osoby) {
            if (osoba instanceof Student){

            }
        }
    }
    public static void wpiszDane(List<Osoba> osoby,List<Kurs> kursy){
        Scanner scan = new Scanner(System.in);
        System.out.println("Jaki obiekt chcesz dodać: \n1.Osobę \n2.Kurs");
        System.out.println("Wypbierz 1 lub 2:");
        String kategoria = scan.nextLine();
    }
    public static void wyszukaj(int kategoria){
//        Wyszukaj albo 1.Pracownika albo 2.Studenta albo 3.Kurs
        switch (kategoria){
            case 1:

                break;
            case 2:

                break;
            case 3:

                break;
        }
    }
}
