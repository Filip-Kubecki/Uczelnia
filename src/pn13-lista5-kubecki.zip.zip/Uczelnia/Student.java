package Uczelnia;
import java.util.ArrayList;

public class Student extends Osoba {
    private int nrIndeksu;
    private int rokStudiow;
    private ArrayList<Kurs> kursy;
    private boolean uczestnikERASMUS;
    private boolean studentIStopnia;
    private boolean studentIIStopnia;
    private boolean studiaStacjonarne;
    private boolean studianiestacjonarne;

    public Student(String imie, String nazwisko, String PESEL, int wiek, String plec, int nrIndeksu, int rokStudiow, ArrayList<Kurs> kursy, boolean uczestnikERASMUS, boolean studentIStopnia, boolean studentIIStopnia, boolean studiaStacjonarne, boolean studianiestacjonarne) {
        super(imie, nazwisko, PESEL, wiek, plec);
        this.nrIndeksu = nrIndeksu;
        this.rokStudiow = rokStudiow;
        this.kursy = kursy;
        this.uczestnikERASMUS = uczestnikERASMUS;
        this.studentIStopnia = studentIStopnia;
        this.studentIIStopnia = studentIIStopnia;
        this.studiaStacjonarne = studiaStacjonarne;
        this.studianiestacjonarne = studianiestacjonarne;
    }
}
