package Uczelnia;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class PracownikUczelni extends Osoba{
    private int stazPracy;
    private int pensja;
//    private String stanowisko;

    public PracownikUczelni(String imie, String nazwisko, String PESEL, int wiek, String plec, int stazPracy, int pensja) {
        super(imie, nazwisko, PESEL, wiek, plec);
        this.stazPracy = stazPracy;
        this.pensja = pensja;
    }

    public int getStazPracy() {
        return stazPracy;
    }

    public void setStazPracy(int stazPracy) {
        this.stazPracy = stazPracy;
    }

    public int getPensja() {
        return pensja;
    }

    public void setPensja(int pensja) {
        this.pensja = pensja;
    }
}
