package Uczelnia;

public class PracownikAdministracyjny extends PracownikUczelni{
    public enum stanowiskoPracy {
        Referent,
        Specjalista,
        StarszySpecjalista;
    }

    private int liczbaNadgodzin;
    private stanowiskoPracy stanowisko;

    public PracownikAdministracyjny(String imie, String nazwisko, String PESEL, int wiek, String plec, int stazPracy, int pensja, int liczbaNadgodzin, stanowiskoPracy stanowisko) {
        super(imie, nazwisko, PESEL, wiek, plec, stazPracy, pensja);
        this.liczbaNadgodzin = liczbaNadgodzin;
        this.stanowisko = stanowisko;
    }

    public int getLiczbaNadgodzin() {
        return liczbaNadgodzin;
    }

    public void setLiczbaNadgodzin(int liczbaNadgodzin) {
        this.liczbaNadgodzin = liczbaNadgodzin;
    }
}
